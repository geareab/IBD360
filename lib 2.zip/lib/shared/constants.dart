import 'package:flutter/material.dart';

class Constants {
  static String appId = "1:377531536938:web:8b3ef331e217f9ccc91553";
  static String apiKey = "AIzaSyB_5d5uozwa-G6JoiTpHdknOpIuTOp6vDM";
  static String messagingSenderId = "377531536938";
  static String projectId = "fyp1-af990";
  final primaryColor = const Color(0xFFee7b64);
}
